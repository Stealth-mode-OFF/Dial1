
  # Echo Dialer MVP Design

  This is a code bundle for Echo Dialer MVP Design. The original project is available at https://www.figma.com/design/7KPWbkqHT21RN2sdfM58tV/Echo-Dialer-MVP-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  