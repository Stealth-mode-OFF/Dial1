export const projectId = ""
export const publicAnonKey = ""
